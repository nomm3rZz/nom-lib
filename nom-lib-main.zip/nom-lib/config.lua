return {
    
    NotifyType = 'ox_lib', -- Support for 'ox_lib' 'qb-core' 'es_extended' 'qbx_core' 'okok' and 'custom' (custom requires editing)

    TextUIType = 'ox_lib', -- Support for 'ox_lib' 'ls_textui' (project ls) and 'custom' (custom requires editing)

    debug = false,
}