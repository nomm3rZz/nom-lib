Framework = {}
Framework.keys = {}
Framework.target = {}

exports("GetLibrary", function()
    return Framework
end)

-- Framework and dependency detection
local qb = GetResourceState('qb-core') == 'started'
local qbx = GetResourceState('qbx_core') == 'started'

local framework = qbx and 'qbx_core' or qb and 'qb-core' or nil
if not framework then 
    return error('^1[nom-lib]^7 Unable to find a ^3framework^7, This could be because you are using a ^3modified framework name^7.')
else print('^1[nom-lib]^7 Your detected framework is: ^3'..framework..'^7')
end

Framework.framework = framework

local file_path = ('bridge/frameworks/%s/server.lua'):format(framework)

local resourceFile = LoadResourceFile(cache.resource, file_path)

if not resourceFile then
    return error(("Unable to find file at path '%s'"):format(file_path))
end

local ld, err = load(resourceFile, ('@@%s/%s'):format(cache.resource, file_path))

if not ld or err then
    return error(err)
end

ld()

-- Detect and load keys system
local qb_vehiclekeys = GetResourceState('qb-vehiclekeys') == 'started'
local qbx_vehiclekeys = GetResourceState('qbx_vehiclekeys') == 'started'
local renewed_vehiclekeys = GetResourceState('Renewed-VehicleKeys') == 'started'
local wasabi_carlock = GetResourceState('wasabi_carlock') == 'started'
local keys = qb_vehiclekeys and 'qb-vehiclekeys' or qbx_vehiclekeys and 'qbx_vehiclekeys' or renewed_vehiclekeys and 'Renewed-VehicleKeys' or wasabi_carlock and 'wasabi_carlock' or nil

if not keys then 
    print('^1[nom-lib]^7 Unable to find your keys system, defaulting to placeholder.')
    keys = 'placeholder'
end

Framework.keys = require(string.format('bridge.keys.%s.server', keys))



print('^1[nom-lib]^7 ^2Loaded Modules^7')