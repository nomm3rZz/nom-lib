---@diagnostic disable: duplicate-set-field
local QBCore = exports['qb-core']:GetCoreObject()
local PlayerData


local function GetConvertedClothes(oldClothes)
    local clothes = {}
    local components = {
        ['arms'] = "arms",
        ['tshirt_1'] = "t-shirt", 
        ['torso_1'] = "torso2", 
        ['bproof_1'] = "vest",
        ['decals_1'] = "decals", 
        ['pants_1'] = "pants", 
        ['shoes_1'] = "shoes", 
        ['helmet_1'] = "hat", 
        ['chain_1'] = "accessory", 
    }
    local textures = {
        ['tshirt_1'] = 'tshirt_2', 
        ['torso_1'] = 'torso_2',
        ['bproof_1'] = 'bproof_2',
        ['decals_1'] = 'decals_2',
        ['pants_1'] = 'pants_2',
        ['shoes_1'] = 'shoes_2',
        ['helmet_1'] = 'helmet_2',
        ['chain_1'] = 'chain_2',
    }
    for k,v in pairs(oldClothes) do 
        local component = components[k]
        if component then 
            local texture = textures[k] and (oldClothes[textures[k]] or 0) or 0
            clothes[component] = {item = v, texture = texture}
        end
    end
    return clothes
end

function Framework.bridgeNotify(msg, type, duration)
    QBCore.Functions.Notify(msg, 'primary', duration)
end

function Framework.GetPlayerGroups()
    local Player = QBCore.Functions.GetPlayerData()
    return Player.job.name, Player.gang.name
end

function Framework.GetPlayers()
    local QBCore = exports['qb-core']:GetCoreObject()
    local playerData = QBCore.Functions.GetPlayerData()
    --print("QBCore PlayerData: ", json.encode(playerData))  -- Add debug print
    return playerData
end

function Framework.GetPlayerGroupInfo(job)
    local Player = QBCore.Functions.GetPlayerData()
    local info

    if job then
        if Player.job and Player.job.name then
            info = {
                name = Player.job.name,
                grade = Player.job.grade and Player.job.grade.level or 0,
                label = Player.job.label or "Unemployed",
                onduty = Player.job.onduty or false -- Add onDuty status check
            }
        else
            -- Default values for unemployed players
            info = {
                name = "unemployed",
                grade = 0,
                label = "Unemployed",
                onduty = false
            }
        end
    else
        if Player.gang and Player.gang.name then
            info = {
                name = Player.gang.name,
                grade = Player.gang.grade and Player.gang.grade.level or 0,
                label = Player.gang.label or "No Gang",
                onduty = false -- Assuming gangs don't have onduty checks
            }
        else
            -- Default values for players not in a gang
            info = {
                name = "no_gang",
                grade = 0,
                label = "No Gang",
                onduty = false
            }
        end
    end

    return info
end


function Framework.GetSex()
    local Player = QBCore.Functions.GetPlayerData()
    return Player.charinfo.gender
end

function Framework.IsDead()
    PlayerData = QBCore.Functions.GetPlayerData()
    return PlayerData.metadata.isdead
end

function Framework.SetOutfit(outfit) 
    if outfit then 
        TriggerEvent('qb-clothing:client:loadOutfit', {outfitData = GetConvertedClothes(outfit)})
    else 
        TriggerServerEvent("qb-clothes:loadPlayerSkin")
    end 
end

function Framework.DeleteVehicle(vehicle)
    if not DoesEntityExist(vehicle) then
        Wait(100)
        return
    end
    SetEntityAsMissionEntity(vehicle, true, true)
    return DeleteVehicle(vehicle)
end

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    TriggerEvent('nom-lib:playerLoaded')
end)

RegisterNetEvent('QBCore:Player:SetPlayerData', function(val)
    PlayerData = val
end)

AddEventHandler('gameEventTriggered', function(event, data)
    if event ~= 'CEventNetworkEntityDamage' then return end
    local victim, victimDied = data[1], data[4]
    if not IsPedAPlayer(victim) then return end
    local player = PlayerId()
    if victimDied and NetworkGetPlayerIndexFromPed(victim) == player and (IsPedDeadOrDying(victim, true) or IsPedFatallyInjured(victim)) then
        TriggerEvent('nom-lib:playerDied')
    end
end)