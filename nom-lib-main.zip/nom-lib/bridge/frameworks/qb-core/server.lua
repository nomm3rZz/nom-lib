---@diagnostic disable: duplicate-set-field
local QBCore = exports['qb-core']:GetCoreObject()
local ox_inventory = GetResourceState('ox_inventory') == 'started' and true or false


function Framework.GetIdentifier(source)
    local player = QBCore.Functions.GetPlayer(source)
    return player.PlayerData.citizenid
end

function Framework.GetName(source)
    local player = QBCore.Functions.GetPlayer(source)
    return player.PlayerData.charinfo.firstname .. ' ' .. player.PlayerData.charinfo.lastname
end

function Framework.GetJobCount(source, job)
    local amount = 0
    local players = QBCore.Functions.GetQBPlayers()
    for _, v in pairs(players) do
        if v and v.PlayerData.job.name == job then
            amount = amount + 1
        end
    end
    return amount
end

function Framework.GetPlayers()
    local players = QBCore.Functions.GetQBPlayers()
    local formattedPlayers = {}
    for _, v in pairs(players) do
        if v and v.PlayerData then
            local player = {
                job = v.PlayerData.job.name,
                gang = v.PlayerData.gang.name,
                source = v.PlayerData.source,
                birthdate = v.PlayerData.birthdate
            }
            table.insert(formattedPlayers, player)
        else
            print("Player data missing for source: " .. tostring(v))
        end
    end
    return formattedPlayers
end

function Framework.GetPlayerBySource(source)
    local players = QBCore.Functions.GetQBPlayers()
    for _, v in pairs(players) do
        if v and v.PlayerData and v.PlayerData.source == source then
            return v
        end
    end
    return nil
end

function Framework.GetPlayerGroups(source)
    local player = QBCore.Functions.GetPlayer(source)
    return player.PlayerData.job, player.PlayerData.gang
end

function Framework.GetPlayerJobInfo(source)
    local player = QBCore.Functions.GetPlayer(source)
    local job = player.PlayerData.job
    return {
        name = job.name,
        label = job.label,
        grade = job.grade,
        gradeName = job.grade.name,
    }
end

function Framework.GetPlayerGangInfo(source)
    local player = QBCore.Functions.GetPlayer(source)
    local gang = player.PlayerData.gang
    return {
        name = gang.name,
        label = gang.label,
        grade = gang.grade,
        gradeName = gang.grade.name,
    }
end

function Framework.GetDob(source)
    local player = QBCore.Functions.GetPlayer(source)
    return player.PlayerData.charinfo.birthdate
end

function Framework.GetSex(source)
    local player = QBCore.Functions.GetPlayer(source)
    return player.PlayerData.charinfo.gender
end

function Framework.RemoveItem(source, item, count)
    local player = QBCore.Functions.GetPlayer(source)
    return player.Functions.RemoveItem(item, count)
end

function Framework.AddItem(source, item, count)
    local player = QBCore.Functions.GetPlayer(source)
    return player.Functions.AddItem(item, count)
end

function Framework.HasItem(source, _item)
    local player = QBCore.Functions.GetPlayer(source)
    local item = player.Functions.GetItemByName(_item)
    return item and (item.count or item.amount) or 0
end

function Framework.GetInventory(source)
    local player = QBCore.Functions.GetPlayer(source)
    if not player then
        print("Player not found for source: " .. tostring(source))
        return {}
    end
    local items = {}
    local data = ox_inventory and exports.ox_inventory:GetInventoryItems(source) or player.PlayerData.items
    for slot, item in pairs(data) do
        table.insert(items, {
            name = item.name,
            label = item.label,
            count = ox_inventory and item.count or item.amount,
            weight = item.weight,
            metadata = ox_inventory and item.metadata or item.info
        })
    end
    return items
end


function Framework.SetJob(source, jobName, jobGrade)
    local player = QBCore.Functions.GetPlayer(source)
    local job = tostring(jobName)
    local grade = tonumber(jobGrade) or 0
    return player.Functions.SetJob(job, grade)
end

function Framework.RegisterUseableItem(item, cb)
    QBCore.Functions.CreateUseableItem(item, cb)
end

function Framework.GetMoney(source, type)
    local player = QBCore.Functions.GetPlayer(source)
    local amount

    if type == 'cash' then 
        amount = player.PlayerData.money.cash
    else 
        amount =  player.PlayerData.money.bank
    end

    return amount
end

function Framework.RemoveMoney(source, type, amount) 
    local player = QBCore.Functions.GetPlayer(source)
    
    -- Ensure type matches the intended structure
    if type ~= 'cash' and type ~= 'bank' then
        print("Invalid money type:", type)
        return false
    end
    
    return player.Functions.RemoveMoney(type, amount)
end

function Framework.AddMoney(source, type, amount) 
    local player = QBCore.Functions.GetPlayer(source)
    
    -- Ensure type matches the intended structure
    if type ~= 'cash' and type ~= 'bank' then
        print("Invalid money type:", type)
        return false
    end
    
    return player.Functions.AddMoney(type, amount)
end

function Framework.AddCommand(name, help, arguments, argsrequired, callback, permission, ...)
    return QBCore.Commands.Add(name, help, arguments, argsrequired, callback, permission, ...)
end