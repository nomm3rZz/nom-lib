---@diagnostic disable: duplicate-set-field
local qbx_core = exports['qbx_core']
local ox_inventory = exports['ox_inventory']

function Framework.GetIdentifier(source)
    local player = qbx_core:GetPlayer(source)
    return player.PlayerData.citizenid
end

function Framework.GetName(source)
    local player = qbx_core:GetPlayer(source)
    return player.PlayerData.charinfo.firstname .. ' ' .. player.PlayerData.charinfo.lastname
end

function Framework.GetJobCount(source, job)
    local amount = 0
    local players = qbx_core:GetQBPlayers()
    for _, v in pairs(players) do
        if v and v.PlayerData.job.name == job then
            amount = amount + 1
        end
    end
    return amount
end

function Framework.GetPlayers(src)
    local players = qbx_core:GetQBPlayers()
    for _, v in pairs(players) do
        if v.PlayerData.source == src then
            return v
        end
    end
    return nil
end

function Framework.GetPlayerBySource(source)
    local players = qbx_core:GetQBPlayers()
    for _, v in pairs(players) do
        if v and v.PlayerData and v.PlayerData.source == source then
            return v
        end
    end
    return nil  -- Player not found
end

function Framework.GetPlayerGroups(source)
    local player = qbx_core:GetPlayer(source)
    return player.PlayerData.job, player.PlayerData.gang
end

function Framework.GetPlayerJobInfo(source)
    local player = qbx_core:GetPlayer(source)
    local job = player.PlayerData.job
    return {
        name = job.name,
        label = job.label,
        grade = job.grade,
        gradeName = job.grade.name,
    }
end

function Framework.GetPlayerGangInfo(source)
    local player = qbx_core:GetPlayer(source)
    local gang = player.PlayerData.gang
    return {
        name = gang.name,
        label = gang.label,
        grade = gang.grade,
        gradeName = gang.grade.name,
    }
end

function Framework.GetDob(source)
    local player = qbx_core:GetPlayer(source)
    return player.PlayerData.charinfo.birthdate
end

function Framework.GetSex(source)
    local player = qbx_core:GetPlayer(source)
    return player.PlayerData.charinfo.gender
end

function Framework.RemoveItem(source, item, count)
    return ox_inventory:RemoveItem(source, item, count)
end

function Framework.AddItem(source, item, count)
    return ox_inventory:AddItem(source, item, count)
end

function Framework.HasItem(source, _item)
    local player = qbx_core:GetPlayer(source)

    if not player then
        print("Error: Player object is nil for source:", source)
        return false -- Return false when player doesn't exist
    end

    local item = player.Functions.GetItemByName(_item)
    return item and (item.count or item.amount) or 0
end

function Framework.GiveKeys(source, plate)
    if not plate or plate == "" then
        print("Failed to give keys. Plate is missing!")
        return false
    end
    return exports.qbx_vehiclekeys:GiveKeys(source, plate)
end

function Framework.GetInventory(source)
    local items = {}
    local data = ox_inventory:GetInventoryItems(source)
    for slot, item in pairs(data) do
        table.insert(items, {
            name = item.name,
            label = item.label,
            count = item.count,
            weight = item.weight,
            metadata = item.metadata
        })
    end
    return items
end

function Framework.SetJob(source, jobName, jobGrade)
    local player = qbx_core:GetPlayer(source)
    local job = tostring(jobName)
    local grade = tonumber(jobGrade) or 0 
    return player.Functions.SetJob(job, grade)
end

function Framework.RegisterUseableItem(item, cb)
    qbx_core:CreateUseableItem(item, cb)
end

function Framework.GetMoney(source, type)
    local player = qbx_core:GetPlayer(source)
    local amount

    if type == 'cash' then 
        amount = player.PlayerData.money.cash
    else 
        amount =  player.PlayerData.money.bank
    end

    return amount
end

function Framework.RemoveMoney(source, type, amount) 
    local player = qbx_core:GetPlayer(source)
    
    -- Ensure type matches the intended structure
    if type ~= 'cash' and type ~= 'bank' then
        print("Invalid money type:", type)
        return false
    end
    
    return player.Functions.RemoveMoney(type, amount)
end

function Framework.AddMoney(source, type, amount) 
    local player = qbx_core:GetPlayer(source)
    
    -- Ensure type matches the intended structure
    if type ~= 'cash' and type ~= 'bank' then
        print("Invalid money type:", type)
        return false
    end
    
    return player.Functions.AddMoney(type, amount)
end

function Framework.AddCommand(name, help, arguments, argsrequired, callback, permission, ...)
    local QBCore = exports['qb-core']:GetCoreObject()
    return QBCore.Commands.Add(name, help, arguments, argsrequired, callback, permission, ...)
end