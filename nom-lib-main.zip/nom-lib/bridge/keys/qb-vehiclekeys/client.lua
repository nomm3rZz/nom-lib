return {

  HasKeys = function(vehicle)
    return exports.qb-vehiclekeys:HasKeys(vehicle)
  end
}