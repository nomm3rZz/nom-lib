return {
  AddKeys = function(source, vehicle)
    return error('We are not supporting your Keys system yet, let us know in our discord and we will add it!')
  end,
  
  RemoveKeys = function(source, vehicle)
    return error('We are not supporting your Keys system yet, let us know in our discord and we will add it!')
  end,

  HasKeys = function(source, vehicle)
    return error('We are not supporting your Keys system yet, let us know in our discord and we will add it!')
  end
}