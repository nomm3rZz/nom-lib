return {
  HasKeys = function(vehicle)
    return error('We are not supporting your Keys system yet, let us know in our discord and we will add it!')
  end
}