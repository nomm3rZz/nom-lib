fx_version 'cerulean'
game 'gta5'
use_experimental_fxv2_oal 'yes'
lua54 'yes'

author "nomm3rZz"
description 'A library of functions for multi-frameworks for NOM CREATIONS.'
version '1.0.0'

shared_script {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    'modules/init/client.lua',
    'modules/functions/client.lua',
    'customize.lua'
}

server_scripts {
    'modules/init/server.lua',
    'modules/functions/server.lua',
    '@oxmysql/lib/MySQL.lua'
}

files {
    'bridge/**/**/*.lua'
}

dependencies {
    'ox_lib',
    'oxmysql'
}
